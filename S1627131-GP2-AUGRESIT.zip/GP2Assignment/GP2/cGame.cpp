#include "cGame.h"
#include "cCamera.h"
#include "cAudio.h"
#include <iostream>
#include <string>



Vertex vertices[] = { Vertex(glm::vec3(-0.5, -0.5, 0), glm::vec2(0.0, 0.0)),
					Vertex(glm::vec3(0, 0.5, 0), glm::vec2(0.5, 1.0)),
					Vertex(glm::vec3(0.5, -0.5, 0), glm::vec2(1.0, 0.0)) };

unsigned int indices[] = { 0, 1, 2 };

Transform transform;

MainGame::MainGame()
{
	_gameState = GameState::PLAY;
	Display* _gameDisplay = new Display(); //new display
    Mesh* mesh1();
	Mesh* mesh2();
	Mesh* mesh3();
	Texture* texture();
	Texture* texture1();
	Texture* texture2();
	Shader* shader();
	Audio* audio();
}

MainGame::~MainGame()
{
}



void MainGame::run()
{
	initSystems(); 
	gameLoop();
}

void MainGame::initSystems()
{
	_gameDisplay.initDisplay(); 
	//mesh2.init(vertices, sizeof(vertices) / sizeof(vertices[0]), indices, sizeof(indices) / sizeof(indices[0])); //size calcuated by number of bytes of an array / no bytes of one element
	mesh1.loadModel("..\\res\\stickman.obj");
	mesh2.loadModel("..\\res\\monkey3.obj");
	mesh3.loadModel("..\\res\\Chair.obj");
	
	texture.init("..\\res\\Water.jpg");
	texture1.init("..\\res\\bricks.jpg");
	texture2.init("..\\res\\grass.jpg");

	shader.init("..\\res\\shader"); //new shader

	shot = audio.loadSound("..\\res\\shot.wav");
    backgroundMusic = audio.loadSound("..\\res\\Map.wav");

	speed = 0.1f;

	myCamera.initCamera(glm::vec3(0, 0, -5), 70.0f, (float)_gameDisplay.getWidth()/_gameDisplay.getHeight(), 0.01f, 1000.0f);
	counter = 0.0f;
}

void MainGame::gameLoop()
{
	audio.playSound(backgroundMusic);
	while (_gameState != GameState::EXIT)
	{
		processInput();
		drawGame();	
	}
}

void MainGame::processInput()
{

	SDL_Event evnt;

	while(SDL_PollEvent(&evnt)) //get and process events
	{
		switch (evnt.type)
		{
			case SDL_QUIT:
				_gameState = GameState::EXIT;
				break;
		}
	}	
}


void MainGame::drawGame()
{
	_gameDisplay.clearDisplay(0.0f, 0.0f, 0.0f, 1.0f);
	
	transform.SetPos(glm::vec3(2, 0, 0));
	transform.SetRot(glm::vec3(counter*0.5, 0.0, 0.0));
	transform.SetScale(glm::vec3(0.005, 0.005, 0.005));
	shader.Bind();
	shader.Update(transform, myCamera);
	texture.Bind(0);
	mesh1.draw();
//------------------------------------------------------------
	transform.SetPos(glm::vec3(0.0, 0.0, 0.0));
	transform.SetRot(glm::vec3(0.0, counter*0.5, 0.0));
	transform.SetScale(glm::vec3(0.05, 0.05, 0.05));
	shader.Bind();
	shader.Update(transform, myCamera);
	texture1.Bind(0);
	mesh2.draw();


//-------------------------------------------------------------
	transform.SetPos(glm::vec3(-2, -1, 0.0));
	transform.SetRot(glm::vec3(0.0, counter*0.5, 0.0));
	transform.SetScale(glm::vec3(0.01, 0.01, 0.01));
	shader.Bind();
	shader.Update(transform, myCamera);
	texture2.Bind(0);
	mesh3.draw();
		

	counter = counter + 0.01f;
	glEnableClientState(GL_COLOR_ARRAY); 
	glEnd();

	_gameDisplay.swapBuffer();
} 