#pragma once
#include <SDL\SDL.h>
#include <GL/glew.h>
#include "cDisplay.h" 
#include "cShader.h"
#include "cMesh.h"
#include "cTexture.h"
#include "cTransform.h"
#include "cAudio.h"

enum class GameState{PLAY, EXIT};

class MainGame
{
public:
	MainGame();
	~MainGame();

	void run();

private:

	void initSystems();
	void processInput();
	void gameLoop();
	void drawGame();
	unsigned int shot;
	unsigned int backgroundMusic;

	Display _gameDisplay;
	GameState _gameState;
	Mesh mesh1;
	Mesh mesh2;
	Mesh mesh3;
	Camera myCamera;
	Texture texture; 
	Texture texture1;
	Texture texture2;
	Shader shader;
	Audio audio;


	float counter;
	float speed;
};

